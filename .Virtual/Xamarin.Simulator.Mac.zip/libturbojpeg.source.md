Original download url:
	https://sourceforge.net/projects/libjpeg-turbo/files/2.0.0/libjpeg-turbo-2.0.0.dmg/download

Original md5 for dmg:
	MD5 (libjpeg-turbo-2.0.0.dmg) = 1538187eb31bf9d447e9189a0afcd473

Original dylib md5:
	MD5 (libturbojpeg.0.2.0.dylib) = bc88b9fcaf3005883da864c0b71d28ab

md5 for dylib after running 'lipo -remove armv7 -remove armv7s -remove arm64 -remove i386 libturbojpeg.0.2.0.dylib -output libturbojpeg.0.dylib'
This reduces the binary size by 80% as we only require 1 architecture.
	MD5 (libturbojpeg.0.dylib) = 906d397a080f1f025844d4d3afa2f415